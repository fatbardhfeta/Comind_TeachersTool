/*
 * By Fatbardh Feta : 7/2/2018 Comind Teacher's Tool
 */
package questiongeneratortool;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fatbardh
 */
public class ContentCreatorPopUpController implements Initializable {

    @FXML
    private TextField nameField;
    @FXML
    private TextField typeField;
    @FXML
    private TextField tagField;
    @FXML
    private TextField lvField;
    @FXML
    private Label error;

    private ArrayList<String> data;
    private Stage thisStage;
    private Content newcontent;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void setStage(Stage stage) {
        this.thisStage = stage;
    }

    public Content getContentData() {
        return newcontent;
    }

    @FXML
    private void save(ActionEvent event) {
        if ("".equals(typeField.getText()) || "".equals(typeField.getText()) || "".equals(typeField.getText()) || "".equals(typeField.getText())) {
            error.setText("You have to fill all the text fields!");
        } else {
            newcontent = new Content();
            data = new ArrayList<>();
            newcontent.setName(nameField.getText());
            newcontent.setLevel(lvField.getText());
            newcontent.setType(typeField.getText());
            
            if( !"".equals(tagField.getText())){
                
            String input = tagField.getText();
            //StringTokenizer st = new StringTokenizer(input, ",");            
            List<String> taglist = Arrays.asList(input.split(","));
            
            Set tag = new HashSet();
            
            for (int i = 0; i < taglist.size() ; i++) {
                tag.add(taglist.get(i));
            }
            newcontent.setTags(tag);
            } else
               newcontent.setTags(null); 
            
            
            thisStage.close();
        }
    }

    @FXML
    private void reset(ActionEvent event) {
        nameField.setText("");
        lvField.setText("");
        typeField.setText("");
        typeField.setText("");
    }

}
