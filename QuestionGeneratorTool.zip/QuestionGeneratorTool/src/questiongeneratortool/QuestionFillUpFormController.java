package questiongeneratortool;

/*
 * By Fatbardh Feta : 7/2/2018 Comind Teacher's Tool
 */
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fatbardh
 */
public class QuestionFillUpFormController implements Initializable {

    @FXML
    private Label warningLabel;
    @FXML
    private Label nameLabel;
    @FXML
    private Label countLabel;
    @FXML
    private Label showStartTime;
    @FXML
    private Label showEndTime;
    @FXML
    private TextField textToSpeachFild;
    @FXML
    private TextField correctHintField;
    @FXML
    private TextField correctHintTextToSpeachField;
    @FXML
    private TextField wrongHintTextField;
    @FXML
    private TextField wrongHintTextToSpeachField;
    @FXML
    private TextField intentionTextFild;
    @FXML
    private TextField intentionentityParameterField;
    @FXML
    private TextField rightAnswerTextField;

    private Stage thisStage;
    
    private Question newQuestion;
    
    private int startPosition;
    private int stopPosition;
    
    //to Do
    //private Indicator indicator;
    
    private List<Intention> intentions;
    
    private List<HintInfo> correctHintInfoList = new ArrayList<>();
    private List<HintInfo> wrongHintInfoList  = new ArrayList<>();

    public void setKnown(String contentName, int questionNr, int startPosition, int stopPosition, Stage thisStage) {
        
        this.startPosition = startPosition;
        this.stopPosition = stopPosition;
        
        showStartTime.setText((startPosition / 60) + " min " + (startPosition % 60) + " sek.");
        showEndTime.setText((stopPosition / 60) + " min " + (stopPosition % 60) + " sek.");
        countLabel.setText("" + questionNr);
        this.thisStage = thisStage;
    }

    @FXML
    private void save(ActionEvent event) {
        if ("".equals(textToSpeachFild.getText())
                || "".equals(rightAnswerTextField.getText())
                || "".equals(wrongHintTextField.getText())
                || "".equals(intentionTextFild.getText())
                || "".equals(correctHintField.getText())
                || "".equals(correctHintTextToSpeachField.getText())
                || "".equals(wrongHintTextToSpeachField.getText())
                || "".equals(intentionentityParameterField.getText())
                || "".equals(correctHintField.getText())
                ) {
            
            warningLabel.setText("Please fill all the text fields!");
            
        } else {
            
            newQuestion = new Question();
            newQuestion.setTextToSpeak(textToSpeachFild.getText());
            newQuestion.setStartPosition(startPosition);
            newQuestion.setStopPosition(stopPosition);
            
            HintInfo newHint = new HintInfo();
            newHint.setType( correctHintField.getText());
            HashMap<String, String> attributes = new HashMap<>();
            attributes.put(correctHintTextToSpeachField.getText(), correctHintTextToSpeachField.getText());
            newHint.setAttributes(attributes);
            correctHintInfoList.add( newHint);
            newQuestion.setCorrectHintInfoList(correctHintInfoList);
            
            HintInfo wrongHint = new HintInfo();
            wrongHint.setType( wrongHintTextField.getText());
            HashMap<String, String> attributes2 = new HashMap<>();
            attributes2.put(wrongHintTextToSpeachField.getText(), wrongHintTextToSpeachField.getText());
            wrongHint.setAttributes(attributes2);
            wrongHintInfoList.add( wrongHint);
            newQuestion.setWrongHintInfoList(wrongHintInfoList);
            
            
            Intention newIntention= new Intention();
            newIntention.setName(intentionTextFild.getText());
            newIntention.setEntityParameter(intentionentityParameterField.getText());
            newIntention.setEntityValue(rightAnswerTextField.getText());
            intentions = new ArrayList<>();
            intentions.add(newIntention);
            newQuestion.setIntentions(intentions);
            
            //to Do
            //newQuestion.setIndicator(indicator);
            

            this.thisStage.close();
        }
    }

    @FXML
    private void reset(ActionEvent event) {

    textToSpeachFild.setText("");
    correctHintField.setText("");
    correctHintTextToSpeachField.setText("");
    wrongHintTextField.setText("");
    wrongHintTextToSpeachField.setText("");
    intentionTextFild.setText("");
    intentionentityParameterField.setText("");
    rightAnswerTextField.setText("");
    }

    public Question getQuestionDetails() {
        return newQuestion;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
}
