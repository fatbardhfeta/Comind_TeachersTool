/*
 * Comind Tool.
 * 
 */
package questiongeneratortool;

import com.fasterxml.jackson.annotation.JsonCreator;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class ContentBuilder {
   // public static List<Content> fromJsonString(String jsonString) {
        //ObjectMapper objectMapper = new ObjectMapper();
        //objectMapper.configure(
        //        DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //List<Content> objArray = null;
        //try {
            //objArray = objectMapper.readValue(jsonString, new TypeReference<List<Content>>(){});
        //    System.out.println(objArray);
        //} catch (IOException e) {
         //   e.printStackTrace();
        //}
        //return objArray;
    //}
}

class Content {
    private String name;
    private String level;
    private String type;
    private String uri;
    private Set<String> tags;
    private List<Question> questions;

    public Content() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public Set<String> getTags() {
        return tags;
    }

    public void setTags(Set<String> tags) {
        this.tags = tags;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

class Question {

    private String textToSpeak;
    private int startPosition;
    private int stopPosition;
    private Indicator indicator;
    private List<Intention> intentions;
    private List<HintInfo> correctHintInfoList = new ArrayList<>();
    private List<HintInfo> wrongHintInfoList  = new ArrayList<>();

    public Question() {
    }

    public String getTextToSpeak() {
        return textToSpeak;
    }

    public void setTextToSpeak(String textToSpeak) {
        this.textToSpeak = textToSpeak;
    }

    public int getStartPosition() {
        return startPosition;
    }

    public void setStartPosition(int startPosition) {
        this.startPosition = startPosition;
    }

    public int getStopPosition() {
        return stopPosition;
    }

    public void setStopPosition(int stopPosition) {
        this.stopPosition = stopPosition;
    }

    public Indicator getIndicator() {
        return indicator;
    }

    public void setIndicator(Indicator indicator) {
        this.indicator = indicator;
    }

    public List<Intention> getIntentions() {
        return intentions;
    }

    public void setIntentions(List<Intention> intentions) {
        this.intentions = intentions;
    }

    public List<HintInfo> getCorrectHintInfoList() {
        return correctHintInfoList;
    }

    public void setCorrectHintInfoList(List<HintInfo> correctHintInfoList) {
        this.correctHintInfoList = correctHintInfoList;
    }

    public List<HintInfo> getWrongHintInfoList() {
        return wrongHintInfoList;
    }

    public void setWrongHintInfoList(List<HintInfo> wrongHintInfoList) {
        this.wrongHintInfoList = wrongHintInfoList;
    }
}

class Intention {
    private String name;
    private String entityParameter;
    private String entityValue;

    public Intention() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEntityParameter() {
        return entityParameter;
    }

    public void setEntityParameter(String entityParameter) {
        this.entityParameter = entityParameter;
    }

    public String getEntityValue() {
        return entityValue;
    }

    public void setEntityValue(String entityValue) {
        this.entityValue = entityValue;
    }
}


class Point {
    private final int x, y;

    @JsonCreator
    public Point(@JsonProperty("x") int x, @JsonProperty("y") int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}

class NormalPoint {
    private final float x, y;

    @JsonCreator
    public NormalPoint(@JsonProperty("x") float x, @JsonProperty("y") float y) {
        if (x < 0 || x >= 1 || y < 0 || y >= 1) {
            throw new InvalidParameterException("x and y values must be in range [0,1)");
        }
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }
}

class Indicator {
    private NormalPoint center;
    private int angle;
    private String textToSpeak;

    public Indicator() {
    }

    public NormalPoint getCenter() {
        return center;
    }

    public void setCenter(NormalPoint center) {
        this.center = center;
    }

    public int getAngle() {
        return angle;
    }

    public void setAngle(int angle) {
        this.angle = angle;
    }

    public String getTextToSpeak() {
        return textToSpeak;
    }

    public void setTextToSpeak(String textToSpeak) {
        this.textToSpeak = textToSpeak;
    }
}


class HintInfo {
    private String type;
    private HashMap<String, String> attributes;

    public HintInfo() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public HashMap<String, String> getAttributes() {
        return attributes;
    }

    public void setAttributes(HashMap<String, String> attributes) {
        this.attributes = attributes;
    }
}