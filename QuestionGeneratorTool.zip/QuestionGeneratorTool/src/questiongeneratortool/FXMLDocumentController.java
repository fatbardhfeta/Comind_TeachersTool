/*
 * By Fatbardh Feta : 7/2/2018 Comind Teacher's Tool
 */
package questiongeneratortool;

import com.google.gson.Gson;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author Fatbardh
 */
public class FXMLDocumentController implements Initializable {

    private String filePath;
    private MediaPlayer mediaPlayer;
    private boolean newQuestionIsRecording = false;
    private Content content;
    private int questionCount;
    private int questionStartTime;
    private int endQuestionTime;
    private Question newQuestion;
    private ObservableList<Question> observableQuestionList;

    // *----- FXML variables -----* //
    @FXML
    private Slider slider;
    @FXML
    private Slider seekSlider;
    @FXML
    private MediaView mediaView;
    @FXML
    private Label startTimeLabel;
    @FXML
    private Label recordinLabel;
    @FXML
    private Button newQuestionButton;
    @FXML
    private Button discardButon;

    //Detail Labels
    @FXML
    private TextField nameText;
    @FXML
    private TextField lvText;
    @FXML
    private TextField typeText;
    @FXML
    private TextField tagTextField;

    //----------QuestionDetails--------
    @FXML
    private TextField textToSpeachText;
    @FXML
    private TextField correctHintField;
    @FXML
    private TextField correctHintToSpeachField;
    @FXML
    private TextField wrongHintField;
    @FXML
    private TextField wrongHintToSpeachfield;
    @FXML
    private TextField intentionNameField;
    @FXML
    private TextField intentionEntityParameterText;
    @FXML
    private TextField entityValueText;
    @FXML
    private TextField startTimeText;
    @FXML
    private TextField stopTimeText;

    @FXML
    private ListView<Question> listView;

    @FXML
    private void openNewContent(ActionEvent event) throws IOException {
        if (mediaPlayer == null) {
            //Choose the Video and check if it is .mp4 format
            FileChooser fileChooser = new FileChooser();
            FileChooser.ExtensionFilter filter = new FileChooser.ExtensionFilter("MP4 format only!", "*.mp4");
            fileChooser.getExtensionFilters().add(filter);
            File file = fileChooser.showOpenDialog(null);
            filePath = file.toURI().toString();

            if (filePath != null) {
                questionCount = 1;
                //create the question list container
                observableQuestionList = FXCollections.observableArrayList();
                listView.setItems(observableQuestionList);
                content = this.handleContentCreation();

                content.setUri(file.toURI().toString());
                if (content != null) {
                    handleContentLabelInfo();
                    this.createMedia();
                }
            }
        }
    }

    @FXML
    private void pauseVideo(ActionEvent event) {
        if (mediaPlayer != null) {
            mediaPlayer.pause();
        }
    }

    @FXML
    private void playVideo(ActionEvent event) {
        if (mediaPlayer != null) {
            mediaPlayer.play();
        }
    }

    @FXML
    private void stopVideo(ActionEvent event) {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
        }
    }

    @FXML
    private void fasterVideo(ActionEvent event) {
        if (mediaPlayer != null) {
            mediaPlayer.setRate(2);
        }
    }

    @FXML
    private void normalSpeedVideo(ActionEvent event) {
        if (mediaPlayer != null) {
            mediaPlayer.setRate(1);
        }
    }

    @FXML
    private void slowerVideo(ActionEvent event) {
        if (mediaPlayer != null) {
            mediaPlayer.setRate(0.5);
        }
    }

    @FXML
    private void muteVideo(ActionEvent event) {
        if (!mediaPlayer.isMute()) {
            mediaPlayer.setMute(true);
        } else {
            mediaPlayer.setMute(false);
        }
    }

    @FXML
    private void closeVideo(ActionEvent event) {
        if (mediaPlayer != null) {
            mediaPlayer.dispose();
        }
    }

    @FXML
    private void close(ActionEvent event) {
        this.close(event);
    }

    @FXML
    private void newQuestion(ActionEvent event) throws IOException {
        if (mediaPlayer != null) {
            if (!newQuestionIsRecording) {
                discardButon.setDisable(false);
                mediaPlayer.play();
                newQuestionIsRecording = true;

                questionStartTime = (int) (mediaPlayer.getCurrentTime()).toSeconds();

                startTimeLabel.setText(startTimeLabel.getText() + ((int) (questionStartTime) / (60) + " min " + ((int) questionStartTime % 60) + " sek."));
                newQuestionButton.setText("Stop Question \nTime");
                recordinLabel.setText("Recording!");

            } else {
                mediaPlayer.pause();
                discardButon.setDisable(true);
                this.resetNewQuestion();

                newQuestion = this.handleQuestionDetail();
                if (newQuestion != null) {
                    if (!newQuestion.getTextToSpeak().equals("")) {

                        observableQuestionList.add(newQuestion);
                        questionCount++;
                    }
                }
            }
        }
    }

    @FXML
    private void deleteQuestion() {
        if (!observableQuestionList.isEmpty()) {
            observableQuestionList.remove(listView.getSelectionModel().getSelectedItem());
            questionCount--;
        }
    }

    @FXML
    private void showQuestion() {
        if (listView.getSelectionModel().getSelectedItem() != null) {

            textToSpeachText.setText(listView.getSelectionModel().getSelectedItem().getTextToSpeak());

            correctHintField.setText(listView.getSelectionModel().getSelectedItem().getCorrectHintInfoList().get(0).getType());
            correctHintToSpeachField.setText(listView.getSelectionModel().getSelectedItem().getCorrectHintInfoList().get(0).getAttributes().keySet().toArray()[0].toString());

            wrongHintField.setText(listView.getSelectionModel().getSelectedItem().getWrongHintInfoList().get(0).getType());
            wrongHintToSpeachfield.setText(listView.getSelectionModel().getSelectedItem().getWrongHintInfoList().get(0).getAttributes().keySet().toArray()[0].toString());

            intentionNameField.setText(listView.getSelectionModel().getSelectedItem().getIntentions().get(0).getName());
            intentionEntityParameterText.setText(listView.getSelectionModel().getSelectedItem().getIntentions().get(0).getEntityParameter());
            entityValueText.setText(listView.getSelectionModel().getSelectedItem().getIntentions().get(0).getEntityValue());

            startTimeText.setText((listView.getSelectionModel().getSelectedItem().getStartPosition()) / 3600
                    + ":" + (listView.getSelectionModel().getSelectedItem().getStartPosition()) / 60
                    + ":" + (listView.getSelectionModel().getSelectedItem().getStartPosition()) % 60);

            stopTimeText.setText((listView.getSelectionModel().getSelectedItem().getStopPosition()) / 3600
                    + ":" + (listView.getSelectionModel().getSelectedItem().getStopPosition()) / 60
                    + ":" + (listView.getSelectionModel().getSelectedItem().getStopPosition()) % 60);
        }
    }

    @FXML
    private void saveEditedQuestion() {
        if (listView.getSelectionModel().getSelectedItem() != null) {
            Question temp = listView.getSelectionModel().getSelectedItem();

            temp.setTextToSpeak(textToSpeachText.getText());
            
            //start-stop Time 
            List<String> srt = Arrays.asList(startTimeText.getText().split(":"));
            temp.setStartPosition(3600 * (Integer.parseInt(srt.get(0))) + 60 * (Integer.parseInt(srt.get(1))) + (Integer.parseInt(srt.get(2))));

            List<String> stp = Arrays.asList(stopTimeText.getText().split(":"));
            temp.setStopPosition(3600 * (Integer.parseInt(stp.get(0))) + 60 * (Integer.parseInt(stp.get(1))) + (Integer.parseInt(stp.get(2))));
            
            //hint modification
            List<HintInfo> correctHintInfoList = new ArrayList<>();
            HintInfo newHint = new HintInfo();
            newHint.setType(correctHintField.getText());
            HashMap<String, String> attributes = new HashMap<>();
            attributes.put(correctHintToSpeachField.getText(), correctHintToSpeachField.getText());
            newHint.setAttributes(attributes);
            correctHintInfoList.add(newHint);
            temp.setCorrectHintInfoList(correctHintInfoList);

            List<HintInfo> wrongHintInfoList = new ArrayList<>();

            HintInfo wrongHint = new HintInfo();
            wrongHint.setType(wrongHintField.getText());
            HashMap<String, String> attributes2 = new HashMap<>();
            attributes2.put(wrongHintToSpeachfield.getText(), wrongHintToSpeachfield.getText());
            wrongHint.setAttributes(attributes2);
            wrongHintInfoList.add(wrongHint);
            temp.setWrongHintInfoList(wrongHintInfoList);

            temp.setCorrectHintInfoList(correctHintInfoList);
            temp.setWrongHintInfoList(wrongHintInfoList);
            
            //Intention modification
            Intention newIntention = new Intention();
            newIntention.setName(intentionNameField.getText());
            newIntention.setEntityParameter(intentionEntityParameterText.getText());
            newIntention.setEntityValue(entityValueText.getText());
            List<Intention> intentions = new ArrayList<>();
            intentions.add(newIntention);
            temp.setIntentions(intentions);

            this.showQuestion();
        }
    }

    @FXML
    private void discardQuestion(ActionEvent event) {
        resetNewQuestion();
    }

    @FXML
    private void openWeb() throws MalformedURLException, URISyntaxException, IOException {
        URI url = new URI("http://www.comind.ai/about.html");
        java.awt.Desktop.getDesktop().browse(url);
    }

    @FXML
    private void saveContentAndClose() throws FileNotFoundException, UnsupportedEncodingException, IOException {
        if (mediaPlayer != null) {
            content.setQuestions(observableQuestionList);
            Gson gson = new Gson();
            String json = gson.toJson(content);

            try (PrintWriter writer = new PrintWriter(content.getName() + ".txt", "UTF-8")) {
                writer.println(json);
                writer.close();
            }      
            //ObjectMapper mapper = new ObjectMapper();
            //mapper.writeValue(new File(content.getName()+".txt"), content);
            this.discardContent();
        }
    }

    @FXML
    private void discardContent() {
        if (mediaPlayer != null) {

            this.resetNewQuestion();
            mediaPlayer.stop();
            mediaPlayer.dispose();
            mediaPlayer = null;
            seekSlider.setValue(0);

            nameText.setText("");
            lvText.setText("");
            typeText.setText("");
            tagTextField.setText("");
            observableQuestionList = FXCollections.observableArrayList();
            listView.setItems(observableQuestionList);

            textToSpeachText.setText("");

            correctHintField.setText("");
            correctHintToSpeachField.setText("");

            wrongHintField.setText("");
            wrongHintToSpeachfield.setText("");

            intentionNameField.setText("");
            intentionEntityParameterText.setText("");
            entityValueText.setText("");

            startTimeText.setText("");

            stopTimeText.setText("");

            if (content != null) {
                content = null;
            }

            if (newQuestion != null) {
                newQuestion = null;
            }

            if (observableQuestionList != null) {
                observableQuestionList = null;
            }
        }
    }

    @FXML
    private void changeContentDetails() {
        Content temp = new Content();
        temp.setName(nameText.getText());
        temp.setLevel(lvText.getText());
        temp.setType(typeText.getText());

        if (!"".equals(tagTextField.getText())) {

            String input = tagTextField.getText();
            //StringTokenizer st = new StringTokenizer(input, ",");            
            List<String> taglist = Arrays.asList(input.split(","));

            Set tag = new HashSet();

            for (int i = 0; i < taglist.size(); i++) {
                tag.add(taglist.get(i));
            }
            temp.setTags(tag);
        } else {
            temp.setTags(null);
        }

        content = temp;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    //Private methods
    private void resetNewQuestion(){
        newQuestionButton.setText("New Question");
        newQuestionIsRecording = false;
        startTimeLabel.setText("Start time: ");
        recordinLabel.setText("");
        discardButon.setDisable(true);

    }

    private Content handleContentCreation() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ContentCreatorPopUp.fxml"));

        Parent tableViewParent = loader.load();

        Scene newscene = new Scene(tableViewParent);

        Stage newStage = new Stage();
        Image image = new Image("pictures/tools.png");
        newStage.getIcons().add(image);
        newStage.setTitle("Comind : New Content!");
        newStage.setScene(newscene);

        ContentCreatorPopUpController myContent = loader.getController();
        myContent.setStage(newStage);

        newStage.initModality(Modality.APPLICATION_MODAL);
        //end of user interaction with the pop up window
        newStage.showAndWait();
        //geting the data of the new queston

        nameText.setText(myContent.getContentData().getName());
        lvText.setText(myContent.getContentData().getLevel());
        typeText.setText(myContent.getContentData().getType());

        return myContent.getContentData();
    }

    private Question handleQuestionDetail() throws IOException {
        //creating the pop up menu to fill in question detail
        if (content != null) {

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("QuestionFillUpForm.fxml"));
            Parent tableViewParent = loader.load();
            Scene newscene = new Scene(tableViewParent);

            //geting a reference to Question Fill up form
            QuestionFillUpFormController formController = loader.getController();

            //addind the known data to the question
            endQuestionTime = (int) (mediaPlayer.getCurrentTime().toSeconds());

            Stage newStage = new Stage();
            Image image = new Image("pictures/tools.png");
            newStage.getIcons().add(image);
            newStage.setTitle("Comind Question Creator Tool");
            newStage.setScene(newscene);

            formController.setKnown(content.getName() + "", questionCount, questionStartTime, endQuestionTime, newStage);

            newStage.initModality(Modality.APPLICATION_MODAL);

            //end of user interaction with the pop up window
            newStage.showAndWait();

            //geting the data of the new queston
            return formController.getQuestionDetails();
        }
        return null;
    }

    private void handleContentLabelInfo() {
        if (content != null) {
            nameText.setText(content.getName());
            lvText.setText(content.getLevel());
            typeText.setText(content.getType());
            if (content.getTags() != null) {
                String s = (content.getTags().toString());

                s = s.substring(1, s.length() - 1);

                tagTextField.setText(s);
            }
        }
    }

    private void createMedia() {
        Media media = new Media(filePath);
        mediaPlayer = new MediaPlayer(media);
        mediaView.setMediaPlayer(mediaPlayer);

        //volume slider
        slider.setValue(mediaPlayer.getVolume() * 100);

        slider.valueProperty().addListener((Observable observable) -> {
            mediaPlayer.setVolume(slider.getValue() / 100);
        });

        //Media Player video slider
        mediaPlayer.currentTimeProperty().addListener((ObservableValue<? extends Duration> observable, Duration oldValue, Duration newValue) -> {
            seekSlider.setValue(newValue.toSeconds());
        });

        mediaPlayer.setOnReady(() -> {
            seekSlider.setMax((media.getDuration()).toSeconds());
        });

        seekSlider.setOnMouseClicked((MouseEvent event1) -> {
            mediaPlayer.seek(Duration.seconds(seekSlider.getValue()));
        });

        //Play the media
        mediaPlayer.play();
    }

}
